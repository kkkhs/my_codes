module.exports = () =>{
  return {
    name: 'test',
    desc: '我是测试数据'
  }
}