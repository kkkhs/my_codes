const test = require('../data/test')

module.exports = () => {
  return{
    test: test()
  }
}