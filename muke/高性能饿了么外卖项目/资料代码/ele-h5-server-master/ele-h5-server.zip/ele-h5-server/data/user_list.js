module.exports = () => {
    return [
      {
        id: 1,
        username: 'khs',
        password: '123456',
        nickname: '第一帅',
        avatar: '/imgs/me_page/avatar.png',
      },
    ]
  }
  