module.exports = () => {
    return {
      list: [
        {
          // 1 为查询结果，2 为店铺
          type: 1,
          label: '比萨',
          resultCount: 453,
        },
        {
          type: 1,
          label: '达美乐比萨',
          resultCount: 1,
        },
        {
          type: 1,
          label: '尊宝比萨',
          resultCount: 1,
        },
        {
          type: 1,
          label: '马上诺比萨',
          resultCount: 1,
        },
        {
          type: 2,
          label: '尊宝比萨（XXX店）',
        },
        {
          type: 1,
          label: '棒约翰比萨',
          resultCount: 1,
        },
        {
          type: 1,
          label: '榴莲比萨',
          resultCount: 1,
        },
        {
          type: 1,
          label: '比萨饼',
          resultCount: 1,
        },
        {
          type: 1,
          label: '栗子饼',
          resultCount: 5,
        },
      ],
    }
  }
