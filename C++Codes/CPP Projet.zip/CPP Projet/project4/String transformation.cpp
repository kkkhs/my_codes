#include <iostream>
#include <string>
using namespace std;


int minDistance(string A, string B)
{
    int aLength = A.length();
    int bLength = B.length();
    int D[bLength + 1][aLength + 1];
    for(int j = 0 ; j <= aLength; j++){
            //初始化第一行
            D[0][j] = j;
    }
    for(int i = 0; i <= bLength; i++){
        //初始化第一列
        D[i][0] = i;
    }

    for(int i = 1; i <= bLength; i++){
        for(int j = 1; j <= aLength; j++){
            //初始化表格
            //D[i][j]=min(min(D[i-1][j]+1,D[i][j-1]+1),(A[j-1]==B[i-1]?D[i-1][j-1]: D[i-1][j-1]+1));
            //D[i][j]是指图中数字区域的每个单元格的值。
            D[i][j] = min(min( D[i - 1][j] + 1, D[i][j - 1] + 1), (A[j - 1] == B[i - 1] ? D[i - 1][j - 1] : D[i - 1][j - 1] + 1));
        }
    }

    return D[bLength][aLength];
}

int main()
{
    string a, b;
    cout << "请输入字符串A和字符串B :" << endl;
    cin >> a;
    cin >> b;

    cout<<"最少次数为："<< minDistance(a, b);

    return 0;
}

// 图片https://img-blog.csdnimg.cn/20200602221217177.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQyNjUwNDMz,size_16,color_FFFFFF,t_70
//  https://blog.csdn.net/qq_42650433/article/details/106505309